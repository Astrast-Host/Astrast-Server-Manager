const Config = require('../config.json');


module.exports = { Proxies, PremiumDomains};